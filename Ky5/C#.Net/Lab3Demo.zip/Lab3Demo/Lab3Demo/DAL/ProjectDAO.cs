﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using Lab3Demo.Entity;
using System.Data;//datatable, dataset

namespace Lab3Demo.DAL
{
    public class ProjectDAO
    {
        string ConnnectionString = ConfigurationManager.
            ConnectionStrings["EmployeeDB"].ConnectionString;

        public List<Project> selectByEmployeeID(int employeeID)
        {
            string query = 
                @"select * from project where id not in (select projectid
                  from projectmember where employeeid = " + employeeID +")";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<Project> projects = new List<Project>();
            foreach (DataRow dr in dt.Rows)
            {
                Project e = new Project()
                {
                    ID = int.Parse(dr[0].ToString()),
                    Name = dr["name"].ToString()
                };
                projects.Add(e);
            }
            return projects;
        }
    }
}
