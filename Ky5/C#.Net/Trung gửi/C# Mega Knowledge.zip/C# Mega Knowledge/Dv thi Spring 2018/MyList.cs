﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class MyList
{
    //Delegate to define the EventHandler
    public delegate void AddingItem(string item);
    public event AddingItem ItemAdded;
    private List<string> items = new List<string>();
    public void addItem(String item)
    {
        items.Add(item);
        if (ItemAdded != null)
        {
            //YOUR CODE -- Raising event ItemAdded here
        }
    }
}

public class Program
{
    static void Main(string[] args)
    {
        MyList mylist = new MyList();
        //YOUR CODE -- Registering the event handler method here


        mylist.addItem("my Item");
        Console.ReadLine();
    }

    //Hander Method for event Item Added
    public static void ItemAddedHandler(string item)
    {
        Console.WriteLine(item + " is just added");
    }
}