﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using Lab3Demo.Entity;
using System.Data;//datatable, dataset
namespace Lab3Demo.DAL
{
    public class EmployeeDAO
    {
        string ConnnectionString = ConfigurationManager.
            ConnectionStrings["EmployeeDB"].ConnectionString;

        public List<Employee> select()
        {
            string query = "select * from Employee";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnnectionString);
            DataTable employeeTBL = new DataTable();
            da.Fill(employeeTBL);
            List<Employee> employees = new List<Employee>();
            foreach(DataRow dr in employeeTBL.Rows)
            {
                Employee e = new Employee()
                {
                    ID = int.Parse(dr[0].ToString()),
                    Name = dr["name"].ToString()
                };
                employees.Add(e);
            }
            return employees;
        }
    }
}
