﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data.SqlClient;
using Lab3Demo.Entity;
using System.Data;//datatable, datasetem.Text;

namespace Lab3Demo.DAL
{
    public class ProjectMemberDAO
    {
        string ConnnectionString = ConfigurationManager.
               ConnectionStrings["EmployeeDB"].ConnectionString;
        public void AddProjectMember(ProjectMember pm)
        {
            string insert = @"insert into ProjectMember values(@eid,
                    @pid,@position,@isfulltime,@date)";
            SqlConnection conn = new SqlConnection(ConnnectionString);
            SqlCommand cmd = new SqlCommand(insert, conn);
            conn.Open();
            cmd.Parameters.AddWithValue("@eid", pm.EmployeeID);
            cmd.Parameters.AddWithValue("@pid", pm.ProjectID);
            cmd.Parameters.AddWithValue("@position", pm.Position);
            cmd.Parameters.AddWithValue("@isfulltime", pm.IsFullTime);
            cmd.Parameters.AddWithValue("@date", pm.Date);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
