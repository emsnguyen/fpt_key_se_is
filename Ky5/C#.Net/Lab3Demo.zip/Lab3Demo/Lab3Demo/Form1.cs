﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Lab3Demo.DAL;
using Lab3Demo.Entity;

namespace Lab3Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //load all employees
            List<Employee> employees = new EmployeeDAO().select();
            foreach (Employee e in employees) listBox1.Items.Add(e);
            listBox1.SelectedIndexChanged += ListBox1_SelectedIndexChanged;
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Employee em = listBox1.SelectedItem as Employee;
            List<Project> projects = new ProjectDAO().
                selectByEmployeeID(em.ID);
            listBox2.Items.Clear();//clear old item
            foreach (Project p in projects) listBox2.Items.Add(p);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Employee em= listBox1.SelectedItem as Employee;
            Project p = listBox2.SelectedItem as Project;
            ProjectMember pm = new ProjectMember()
            {
                EmployeeID = em.ID,
                ProjectID = p.ID,
                Position = textBox1.Text,
                IsFullTime = checkBox1.Checked,
                Date = dateTimePicker1.Value
            };
            new ProjectMemberDAO().AddProjectMember(pm);
            MessageBox.Show(".....");
        }
    }
}
