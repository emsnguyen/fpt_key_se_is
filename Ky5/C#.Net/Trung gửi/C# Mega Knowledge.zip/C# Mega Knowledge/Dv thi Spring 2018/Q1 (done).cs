using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PE_Q1_24_3_2018
{
    class Program
    {
        static void Main(string[] args)
        {
            IFlyable bird = new Bird();
            IFlyable plane = new Plane();
            bird.Fly();
            plane.Fly();
            Console.ReadKey();
        }
    }

    interface IFlyable
    {
        void Fly();
    }

    class Bird : IFlyable
    {
        public void Fly()
        {
            Console.WriteLine("Flap Wings");
        }
    }

    class Plane : IFlyable
    {
        public void Fly()
        {
            Console.WriteLine("Windsurfing");
        }
    }
}
