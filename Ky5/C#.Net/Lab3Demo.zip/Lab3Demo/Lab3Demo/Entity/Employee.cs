﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3Demo.Entity
{
    public class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return Name;
        }
    }

    public class Project
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return Name;
        }
    }

    public class ProjectMember
    {
        public int EmployeeID { get; set; }
        public int ProjectID { get; set; }
        public string Position { get; set; }
        public bool IsFullTime { get; set; }
        public DateTime Date { get; set; }
    }
}
